package com.iphone.aparelhoTelefonico;

public interface AparelhoTelefonico {
    void ligar(Contato numero);

    public void atender();
    public void iniciarCorreioVoz();
}
