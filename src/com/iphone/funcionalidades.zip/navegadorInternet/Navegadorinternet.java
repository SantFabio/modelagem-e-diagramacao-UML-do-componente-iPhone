package com.iphone.navegadorInternet;

public interface Navegadorinternet {
    public void exibirPagina(String url);
    public void adicionarNovaAba(String url);
    public void atualizarPagina();
}
