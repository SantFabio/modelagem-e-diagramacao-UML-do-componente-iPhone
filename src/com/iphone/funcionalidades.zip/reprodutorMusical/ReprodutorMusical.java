package com.iphone.reprodutorMusical;

public interface ReprodutorMusical {
    public void tocar(Musica musica);
    public void pausar();
    public void selecionarMusica(Musica musica);
}
